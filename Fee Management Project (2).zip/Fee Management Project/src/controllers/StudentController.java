package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AdminDao;
import model.StudentModel;

@WebServlet(urlPatterns = {"/reqstudentlogin","/reqstudentdues","/reqstudentlogout","/reqviewremainder","/reqpay","/reqstuforgotpwd"})
public class StudentController extends HttpServlet 
{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		String path=req.getServletPath();
		PrintWriter out=res.getWriter();
		StudentModel sm=new StudentModel();
		if(path.equals("/reqstudentlogin"))
		{
			sm.setEmail(req.getParameter("t3"));
			sm.setStudID(Long.parseLong(req.getParameter("t1")));
			boolean b=new AdminDao().studentlogin(sm);
			if(b)
			{
				  HttpSession session=req.getSession();
			         session.setAttribute("name",sm.getStudID());
			        
				RequestDispatcher rd=req.getRequestDispatcher("welcomestudent.html");
				rd.forward(req, res);
				out.print("Login successful");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
				out.print("Invalid credentials");
			}
		}
		
			else if(path.equals("/reqstuforgotpwd"))
			{
				sm.setEmail(req.getParameter("t1"));
				sm.setStudID(Long.parseLong(req.getParameter("t2")));
				boolean b=new AdminDao().forgotstudpwd(sm);
				if(b)
				{
					out.print("updated successfully");
					RequestDispatcher rd=req.getRequestDispatcher("login.html");
					rd.include(req, res);
				}
				else
				{
					out.print("Something went wrong");
				}
			}
		
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	
	{
		String path=req.getServletPath();
		PrintWriter out=res.getWriter();
		StudentModel sm=new StudentModel();
	
			if(path.equals("/reqstudentdues"))
				{
				HttpSession session =req.getSession();
	       		String name=session.getAttribute("name").toString();
				sm=new AdminDao().paymentform(name);
				out.print("<body bgcolor=DACBC9><center><br><br><cellpadding=5><form action=reqpay><table border=3>");
				out.print("<tr><td>StudentID :</td><td> <input type=text readonly name=t1 value="+sm.getStudID()+"></td></tr>");
				out.print("<tr><td>Fees :</td><td> <input type=text readonly name=t2 value="+sm.getFees()+"></td></tr>");
				out.print("<tr><td>Paid :</td><td> <input type=text readonly name=t3 value="+sm.getPaid()+"></td></tr>");
				out.print("<tr><td>Dues :</td><td> <input type=text readonly name=t4 value="+sm.getDues()+"></td></tr>");
				out.print("<tr><td>Amount :</td><td> <input type=text  name=t5></td></tr>");
				out.print("<tr><td><input type=submit value=Update></td><td> <input type=reset value=Clear></td></tr></table></form>");
		}
		else if(path.equals("/reqpay"))
		{
			sm.setStudID(Long.parseLong(req.getParameter("t1")));
			sm.setFees(Long.parseLong(req.getParameter("t2")));
			sm.setPaid(Long.parseLong(req.getParameter("t3")));
			sm.setDues(Long.parseLong(req.getParameter("t4")));
			sm.setAmount(Long.parseLong(req.getParameter("t5")));
			boolean b=new AdminDao().paystudentfees(sm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reqsearchstudent");
				rd.forward(req, res);
			}
			else
			{
				out.print("payment failed");
			}
		}
		else if(path.equals("/reqstudentlogout"))
		{
			boolean b=new AdminDao().studentlogout(sm);
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.forward(req, res);
		}
		else if(path.equals("/reqviewremainder"))
		{ HttpSession session =req.getSession();
	       String name=session.getAttribute("name").toString();
			StudentModel st=new AdminDao().viewremainder(name);
			out.print("<body bgcolor=DACBC9><center><br><br><table border=2 cellpadding=15><tr bgcolor=skyblue><th>StudentID</th><th>Name</th><th>Email</th><th>Gender</th><th>Course</th><th>Fees</th><th>Paid</th><th>Dues</th><th>Address</th><th>PayDue</th></tr>");
			out.print("<tr><td>"+st.getStudID()+"</td><td>"+st.getName()+"</td><td>"+st.getEmail()+"</td><td>"+st.getGender()+"</td><td>"+st.getCourse()+"</td><td>"+st.getFees()+"</td><td>"+st.getPaid()+"</td><td>"+st.getDues()+"</td><td>"+st.getAddress()+"</td><td><a href=reqstudentdues?id="+st.getStudID()+">PayDue</a></td></tr>");
		}
	}
}
