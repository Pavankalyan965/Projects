package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDao;
import model.AccountantModel;
import model.AdminModel;
import model.StudentModel;


@WebServlet(urlPatterns= {"/reqregisteradmin","/reqadminlogin","/reqregisteraccountant","/reqviewaccountantinfo","/requpdateaccountant","/requpdateaccountantdetails","/reqdeleteaccountant","/reqlogoutaccountant","/reqadminlogout"})
public class AdminController extends HttpServlet 
{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		AdminModel am=new AdminModel();
		StudentModel sm=new StudentModel();
		AccountantModel acm=new AccountantModel();
		String path=req.getServletPath();
		if(path.equals("/reqadminlogin"))
		{
			am.setEmail(req.getParameter("t1"));
			am.setPassword(req.getParameter("t2"));
			boolean b=new AdminDao().adminlogin(am);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeadmin.html");
				rd.forward(req, res);
				out.print("Login successful");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
				out.print("Invalid credentials");
			}
		}
		else if(path.equals("/reqregisteradmin"))
		{
			am.setName(req.getParameter("t1"));
			am.setEmail(req.getParameter("t2"));
			am.setPassword(req.getParameter("t3"));
			am.setMobile(Long.parseLong(req.getParameter("t4")));
			am.setAddress(req.getParameter("t5"));
			boolean b=new AdminDao().adminregister(am);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.forward(req, res);
				out.print("Registration done successfully click here to <a href=login.html>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("adminregister.html");
				rd.include(req, res);
				out.print("Registration failed");
			}
		}
		if(path.equals("/reqregisteraccountant"))
		{
			//AccountantModel acm=new AccountantModel();
			acm.setName(req.getParameter("t1"));
			acm.setEmail(req.getParameter("t2"));
			acm.setPassword(req.getParameter("t3"));
			acm.setMobile(Long.parseLong(req.getParameter("t4").trim()));
			acm.setAddress(req.getParameter("t5"));
			boolean b=new AdminDao().addaccountant(acm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.forward(req, res);
				out.print("Registration done successfully click here to <a href=login.html>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeadmin.html");
				rd.include(req, res);
				out.print("Registration failed");
			}
		}
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		AdminModel am=new AdminModel();
		StudentModel sm=new StudentModel();
		AccountantModel acm=new AccountantModel();
		String path=req.getServletPath();
		
		if(path.equals("/reqviewaccountantinfo"))
		{
			ArrayList<AccountantModel>al=new ArrayList<AccountantModel>();
			al=new AdminDao().viewaccountant();
			out.print("<body bgcolor=DACBC9><center><br><br><table border=2 cellpadding=10><tr bgcolor=skyblue><th>Name</th><th>Email</th><th>Password</th><th>Mobile</th><th>Address</th><th>Update</th><th>Delete</th></tr>");
			for(AccountantModel acc:al)
			{
					out.print("<tr><td>"+acc.getName()+"</td><td>"+acc.getEmail()+"</td><td>"+acc.getPassword()+"</td><td>"+acc.getMobile()+"</td><td>"+acc.getAddress()+"</td><td><a href=requpdateaccountant?id="+acc.getEmail()+">Update</a></td><td><a href=reqdeleteaccountant?id="+acc.getEmail()+">Delete</a></td>");
			}
		}
		else if(path.equals("/requpdateaccountant"))
		{
			ResultSet rs=null;
			acm.setEmail(req.getParameter("id"));
			rs=new AdminDao().updateaccountant(acm);
			try
			{
				if(rs.next())
				{
					out.print("<body bgcolor=DACBC9><center><br><br><form action=requpdateaccountantdetails><table border=3>");
					out.print("<tr><td>Name :</td><td> <input type=text name=t1 value="+rs.getString(1)+"></td></tr>");
					out.print("<tr><td>Email :</td><td> <input type=text readonly name=t2 value="+rs.getString(2)+"></td></tr>");
					out.print("<tr><td>Password :</td><td> <input type=text name=t3 value="+rs.getString(3)+"></td></tr>");
					out.print("<tr><td>Mobile :</td><td> <input type=text  name=t4 value="+rs.getLong(4)+"></td></tr>");
					out.print("<tr><td>Address :</td><td> <input type=text  name=t5 value="+rs.getString(5)+"></td></tr>");
					out.print("<tr><td><input type=submit value=Update></td><td> <input type=reset value=Clear></td></tr></table></form>");
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		
	else if(path.equals("/requpdateaccountantdetails"))
	{
		acm.setName(req.getParameter("t1"));
		acm.setEmail(req.getParameter("t2"));
		acm.setPassword(req.getParameter("t3"));
		acm.setMobile(Long.parseLong(req.getParameter("t4").trim()));
		acm.setAddress(req.getParameter("t5"));
		boolean b=new AdminDao().updateaccountantdetails(acm);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("welcomeadmin.html");
			rd.forward(req, res);
		}
		else
		{
			out.print("failed");
		}
	}
	else if(path.equals("/reqdeleteaccountant"))
	{
		acm.setEmail(req.getParameter("id"));
		boolean b=new AdminDao().deleteaccountant(acm);
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("welcomeadmin.html");
			rd.forward(req, res);
		}
		else
		{
			out.print("failed");
		}
	}
	else if(path.equals("/reqadminlogout"))
	{
		boolean b=new AdminDao().adminlogin(am);
		RequestDispatcher rd=req.getRequestDispatcher("login.html");
		rd.forward(req, res);
		
	}	
}
}
