package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AdminDao;
import model.AccountantModel;
import model.StudentModel;

@WebServlet(urlPatterns = {"/reqaccountantlogin","/reqregisterstudent","/requpdatestudent","/reqviewstudentinfo","/requpdatestudentdetails","/reqdeletestudent","/reqaccountantlogout","/reqsearchstudent","/reqremindstudent","/reqaccforgotpwd"})
public class AccountantController extends HttpServlet
{	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		AccountantModel acm=new AccountantModel();
		StudentModel sm=new StudentModel();
		if(path.equals("/reqaccountantlogin"))
		{
			acm.setEmail(req.getParameter("t1"));
			acm.setPassword(req.getParameter("t2"));
			boolean b=new AdminDao().accountantlogin(acm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeaccountant.html");
				
				rd.forward(req, res);
				out.print("Login successful");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
				out.print("Invalid credentials");
			}
		}
		else if(path.equals("/reqregisterstudent"))
		{
			sm.setStudID(Long.parseLong(req.getParameter("t1")));
			sm.setName(req.getParameter("t2"));
			sm.setEmail(req.getParameter("t3"));
			sm.setGender(req.getParameter("t4"));
			sm.setCourse(req.getParameter("t5"));
			sm.setFees(Long.parseLong(req.getParameter("t6")));
			sm.setPaid(Long.parseLong(req.getParameter("t7")));
			sm.setDues(Long.parseLong(req.getParameter("t8")));
			sm.setAddress(req.getParameter("t9"));
			boolean b=new AdminDao().addstudent(sm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeaccountant.html");
				rd.forward(req, res);
				out.print("Student added successfully");
			}
			else
			{
				out.print("Student registration failed");
			}
		}
		else if(path.equals("/reqaccforgotpwd"))
		{
			acm.setEmail(req.getParameter("t1"));
			acm.setPassword(req.getParameter("t2"));
			boolean b=new AdminDao().forgotaccpwd(acm);
			System.out.println("password:"+acm.getPassword());
			if(b)
			{
				out.print("updated successfully");
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
			}
			else
			{
				out.print("Something went wrong");
			}
		}
	}
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		AccountantModel acm=new AccountantModel();
		StudentModel sm=new StudentModel();
		if(path.equals("/reqviewstudentinfo"))
		{
			ArrayList<StudentModel>al=new ArrayList<StudentModel>();
			al=new AdminDao().viewstudent();
			out.print("<body bgcolor=DACBC9><center><br><br><br><table border=2 cellpadding=10><tr bgcolor=skyblue><th>StudentID</th><th>Name</th><th>Email</th><th>Gender</th><th>Course</th><th>Fees</th><th>Paid</th><th>Dues</th><th>Address</th><th>Update</th><th>Delete</th><th>Remainder</th></tr>");
			for(StudentModel stm:al)
			{
					out.print("<tr><td>"+stm.getStudID()+"</td><td>"+stm.getName()+"</td><td>"+stm.getEmail()+"</td><td>"+stm.getGender()+"</td><td>"+stm.getCourse()+"</td><td>"+stm.getFees()+"</td><td>"+stm.getPaid()+"</td><td>"+stm.getDues()+"</td><td>"+stm.getAddress()+"</td><td><a href=requpdatestudent?id="+stm.getStudID()+">Update</a></td><td><a href=reqdeletestudent?id="+stm.getStudID()+">Delete</a></td><td><a href=reqremindstudent?id="+stm.getStudID()+">Remainder</a></td>");
			}
		}
		else if(path.equals("/requpdatestudent"))
		{
			ResultSet rs=null;
			sm.setStudID(Long.parseLong(req.getParameter("id")));
			rs=new AdminDao().updatestudent(sm);
			try
			{
				if(rs.next())
				{
					out.print("<body bgcolor=DACBC9><center><br><br><form action=requpdatestudentdetails><table border=3>");
					out.print("<tr><td>StudentID :</td><td> <input type=text readonly name=t1 value="+rs.getLong(1)+"></td></tr>");
					out.print("<tr><td>Name :</td><td> <input type=text name=t2 value="+rs.getString(2)+"></td></tr>");
					out.print("<tr><td>Email :</td><td> <input type=text name=t3 value="+rs.getString(3)+"></td></tr>");
					out.print("<tr><td>Gender :</td><td> <input type=text name=t4 value="+rs.getString(4)+"></td></tr>");
					out.print("<tr><td>Course :</td><td> <input type=text name=t5 value="+rs.getString(5)+"></td></tr>");
					out.print("<tr><td>Fees :</td><td> <input type=text  name=t6 value="+rs.getLong(6)+"></td></tr>");
					out.print("<tr><td>Paid :</td><td> <input type=text  name=t7 value="+rs.getLong(7)+"></td></tr>");
					out.print("<tr><td>Dues :</td><td> <input type=text  name=t8 value="+rs.getLong(8)+"></td></tr>");
					out.print("<tr><td>Address :</td><td> <input type=text  name=t9 value="+rs.getString(9)+"></td></tr>");
					out.print("<tr><td><input type=submit value=Update></td><td> <input type=reset value=Clear></td></tr></table></form>");
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		else if(path.equals("/requpdatestudentdetails"))
		{
			sm.setStudID(Long.parseLong(req.getParameter("t1")));
			sm.setName(req.getParameter("t2"));
			sm.setEmail(req.getParameter("t3"));
			sm.setGender(req.getParameter("t4"));
			sm.setCourse(req.getParameter("t5"));
			sm.setFees(Long.parseLong(req.getParameter("t6")));
			sm.setPaid(Long.parseLong(req.getParameter("t7")));
			sm.setDues(Long.parseLong(req.getParameter("t8")));
			sm.setAddress(req.getParameter("t9"));
			boolean b=new AdminDao().updatestudentdetails(sm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeaccountant.html");
				rd.forward(req, res);
			}
			else
			{
				out.print("failed");
			}
		}
		else if(path.equals("/reqdeletestudent"))
		{
			sm.setStudID(Long.parseLong(req.getParameter("id")));
			boolean b=new AdminDao().deletestudent(sm);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcomeaccountant.html");
				rd.forward(req, res);
			}
			else
			{
				out.print("failed");
			}
		}
		else if(path.equals("/reqsearchstudent"))
		{
			ArrayList<StudentModel>al=new ArrayList<StudentModel>();
			sm.setStudID(Long.parseLong(req.getParameter("t1")));
			al=new AdminDao().searchstudentbyID(sm);
			out.print("<body bgcolor=DACBC9><center><br><br><table border=2 cell padding=15><tr bgcolor=skyblue><th>StudentID</th><th>Name</th><th>Email</th><th>Gender</th><th>Course</th><th>Fees</th><th>Paid</th><th>Dues</th><th>Address</th></tr>");
			for(StudentModel stm:al)
			{
					out.print("<tr><td>"+stm.getStudID()+"</td><td>"+stm.getName()+"</td><td>"+stm.getEmail()+"</td><td>"+stm.getGender()+"</td><td>"+stm.getCourse()+"</td><td>"+stm.getFees()+"</td><td>"+stm.getPaid()+"</td><td>"+stm.getDues()+"</td><td>"+stm.getAddress()+"</td>");
			}
		}
		else if(path.equals("/reqremindstudent"))
		{
			sm.setStudID(Long.parseLong(req.getParameter("id")));
			boolean b=new AdminDao().senddueremainder(sm);
			if(b)
			{
				out.print("<body bgcolor=DACBC9><center><br><br>Remainder sent successfully click here to <a href=reqviewstudentinfo>view previous page</a>");
			}
			else
			{
				out.print("No dues pending for this student. Click here to <a href=reqviewstudentinfo>view previous page</a>");
				
			}
		}
		else if(path.equals("/reqaccountantlogout"))
		{
			boolean b=new AdminDao().accountantlogout(sm);
			RequestDispatcher rd=req.getRequestDispatcher("login.html");
			rd.forward(req, res);
			
		}
		
	}
		
}
