package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import model.AccountantModel;
import model.AdminModel;
import model.StudentModel;

public class AdminDao implements DaoInterface
{
	static Connection con=null;
	long SID=0;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/project","pavan","pavan6499");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
	public boolean adminlogin(AdminModel am)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select email,name from adminlogin where email='"+am.getEmail()+"' and password='"+am.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean adminregister(AdminModel am)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			PreparedStatement ps=con.prepareStatement("insert into adminlogin values(?,?,?,?,?)");
			ps.setString(1, am.getName());
			ps.setString(2, am.getEmail());
			ps.setString(3, am.getPassword());
			ps.setLong(4, am.getMobile());
			ps.setString(5, am.getAddress());
			int i=ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}

	public boolean adminlogout(AdminModel am) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		return b;
	}
	
	public boolean addaccountant(AccountantModel acm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			PreparedStatement ps=con.prepareStatement("insert into accountant values(?,?,?,?,?)");
			ps.setString(1, acm.getName());
			ps.setString(2, acm.getEmail());
			ps.setString(3, acm.getPassword());
			ps.setLong(4, acm.getMobile());
			ps.setString(5, acm.getAddress());
			int i=ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<AccountantModel> viewaccountant()
	{
		ArrayList<AccountantModel> al=new ArrayList<AccountantModel>();
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from accountant");
			while(rs.next())
			{
				AccountantModel acm=new AccountantModel();
				acm.setName(rs.getString(1));
				acm.setEmail(rs.getString(2));
				acm.setPassword(rs.getString(3));
				acm.setMobile(rs.getLong(4));
				acm.setAddress(rs.getString(5));
				al.add(acm);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;
	}
	public ResultSet updateaccountant(AccountantModel acm)
	{
		ResultSet rs=null;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from accountant where email='"+acm.getEmail()+"'");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateaccountantdetails(AccountantModel acm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		int i=0;
		try
		{
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("update accountant set name='"+acm.getName()+"',password='"+acm.getPassword()+"',mobile='"+acm.getMobile()+"',address='"+acm.getAddress()+"' where email='"+acm.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
	public boolean deleteaccountant(AccountantModel acm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{	
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("delete from accountant where email='"+acm.getEmail()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
	public boolean accountantlogin(AccountantModel acm)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select email,name from accountant where email='"+acm.getEmail()+"' and password='"+acm.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean addstudent(StudentModel sm)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?)");
			ps.setLong(1, sm.getStudID());
			ps.setString(2, sm.getName());
			ps.setString(3, sm.getEmail());
			ps.setString(4, sm.getGender());
			ps.setString(5, sm.getCourse());
			ps.setLong(6, sm.getFees());
			ps.setLong(7, sm.getPaid());
			ps.setLong(8, sm.getDues());
			ps.setString(9, sm.getAddress());
			int i=ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ArrayList<StudentModel>viewstudent()
	{
		ArrayList<StudentModel> al=new ArrayList<StudentModel>();
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from student");
			while(rs.next())
			{
				StudentModel sm=new StudentModel();
				sm.setStudID(rs.getLong(1));
				sm.setName(rs.getString(2));
				sm.setEmail(rs.getString(3));
				sm.setGender(rs.getString(4));
				sm.setCourse(rs.getString(5));
				sm.setFees(rs.getLong(6));
				sm.setPaid(rs.getLong(7));
				sm.setDues(rs.getLong(8));
				sm.setAddress(rs.getString(9));
				al.add(sm);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;	
	}
	public ResultSet updatestudent(StudentModel sm)
	{
		ResultSet rs=null;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from student where StudId='"+sm.getStudID()+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updatestudentdetails(StudentModel sm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		int i=0;
		try
		{
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("update student set name='"+sm.getName()+"',email='"+sm.getEmail()+"',gender='"+sm.getGender()+"',course='"+sm.getCourse()+"',fees='"+sm.getFees()+"',paid='"+sm.getPaid()+"',dues='"+sm.getDues()+"',address='"+sm.getAddress()+"' where StudID='"+sm.getStudID()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean deletestudent(StudentModel sm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{	
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("delete from student where StudID='"+sm.getStudID()+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean accountantlogout(StudentModel sm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		return b;
	}
	public ArrayList<StudentModel>searchstudentbyID(StudentModel sm)
	{
		ArrayList<StudentModel> al=new ArrayList<StudentModel>();
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from student where StudID='"+sm.getStudID()+"'");
			if(rs.next())
			{
				sm.setStudID(rs.getLong(1));
				sm.setName(rs.getString(2));
				sm.setEmail(rs.getString(3));
				sm.setGender(rs.getString(4));
				sm.setCourse(rs.getString(5));
				sm.setFees(rs.getLong(6));
				sm.setPaid(rs.getLong(7));
				sm.setDues(rs.getLong(8));
				sm.setAddress(rs.getString(9));
				al.add(sm);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return al;	
	
	}
	public boolean studentlogin(StudentModel sm)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select email,StudID from student where email='"+sm.getEmail()+"' and StudID='"+sm.getStudID()+"'");
			if(rs.next())
			{
				
				this.SID=rs.getLong(2);
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
	public boolean studentlogout(StudentModel sm)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		return b;
	}
	public boolean senddueremainder(StudentModel sm)
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs1=st.executeQuery("select dues from student where StudId='"+sm.getStudID()+"'");
			if(rs1.next())
			{
				sm.setDues(rs1.getLong(1));
			ResultSet rs=st.executeQuery("select * from student where StudID= '"+sm.getStudID()+"' and dues='"+sm.getDues()+"'>0 ");
			if(rs.next())
			{
			
					sm.setStudID(rs.getLong(1));
					sm.setName(rs.getString(2));
					sm.setEmail(rs.getString(3));
					sm.setGender(rs.getString(4));
					sm.setCourse(rs.getString(5));
					sm.setFees(rs.getLong(6));
					sm.setPaid(rs.getLong(7));
					sm.setDues(rs.getLong(8));
					sm.setAddress(rs.getString(9));
					
					PreparedStatement ps=con.prepareStatement("insert into paydues values(?,?,?,?,?,?,?,?,?)");
					ps.setLong(1, sm.getStudID());
					ps.setString(2, sm.getName());
					ps.setString(3, sm.getEmail());
					ps.setString(4, sm.getGender());
					ps.setString(5, sm.getCourse());
					ps.setLong(6, sm.getFees());
					ps.setLong(7, sm.getPaid());
					ps.setLong(8, sm.getDues());
					ps.setString(9, sm.getAddress());
					int i=ps.executeUpdate();
					if(i>0)
					{
						b=true;
					}
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
	public StudentModel viewremainder(String id)
	{
		StudentModel s=new StudentModel();
		ResultSet rs=null;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			System.out.println("stu:"+s.getStudID());
			System.out.println(id);
			rs=st.executeQuery("select * from paydues where StudID='"+id+"'");
			
			if(rs.next())
			{
				System.out.println("name:"+s.getName());
				s.setStudID(rs.getLong(1));
				s.setName(rs.getString(2));
				s.setEmail(rs.getString(3));
				s.setGender(rs.getString(4));
				s.setCourse(rs.getString(5));
				s.setFees(rs.getLong(6));
				s.setPaid(rs.getLong(7));
				s.setDues(rs.getLong(8));
				s.setAddress(rs.getString(9));
			
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return s;
	}
	
	public StudentModel paymentform(String id)
	{
		StudentModel sm=new StudentModel();
		ResultSet rs=null;
		con=AdminDao.getConnectionObject();
		
		try
		{
			Statement st=con.createStatement();
		
			rs=st.executeQuery("select StudID,fees,paid,dues from paydues where StudID='"+id+"'");
			if(rs.next())
			{
				sm.setStudID(rs.getLong(1));
				sm.setFees(rs.getLong(2));
				sm.setPaid(rs.getLong(3));
				sm.setDues(rs.getLong(4));
				
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return sm;
	}
	public boolean paystudentfees(StudentModel sm) {
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			int i=stmt.executeUpdate("update student set paid='"+(sm.getPaid()+sm.getAmount())+"',dues='"+(sm.getDues()-sm.getAmount())+"' where StudID='"+sm.getStudID()+"'");
			
			int j=stmt.executeUpdate("update paydues set paid='"+(sm.getPaid()+sm.getAmount())+"',dues='"+(sm.getDues()-sm.getAmount())+"' where StudID='"+sm.getStudID()+"'");
			
			if(i>0 && j>0) 
			{  
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
		
	}
	public boolean forgotaccpwd(AccountantModel acm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			System.out.println("pass1:"+acm.getPassword());
			
			int i=st.executeUpdate("update accountant set password='"+acm.getPassword()+"' where email='"+acm.getEmail()+"'");
			System.out.println("pass2:"+acm.getPassword());
			
			if(i>0)
			{
				System.out.println("pass:"+acm.getPassword());
				
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean forgotstudpwd(StudentModel sm) 
	{
		boolean b=false;
		con=AdminDao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();			
			int i=st.executeUpdate("update student set StudID='"+sm.getStudID()+"' where email='"+sm.getEmail()+"'");
			
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;

	}
}
