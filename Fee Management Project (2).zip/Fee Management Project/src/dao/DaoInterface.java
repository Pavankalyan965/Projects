package dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import model.AccountantModel;
import model.AdminModel;
import model.StudentModel;

public interface DaoInterface 
{
	//Admin module
	public boolean adminlogin(AdminModel am);
	public boolean adminregister(AdminModel am);
	public boolean addaccountant(AccountantModel acm);
	public ArrayList<AccountantModel> viewaccountant();
	public boolean updateaccountantdetails(AccountantModel acm);
	public ResultSet updateaccountant(AccountantModel acm);
	public boolean deleteaccountant(AccountantModel acm);
	public boolean adminlogout(AdminModel am);
	//accountant module
	public boolean accountantlogin(AccountantModel acm);
	public boolean forgotaccpwd(AccountantModel acm);
	public boolean addstudent(StudentModel sm);
	public ArrayList<StudentModel>viewstudent();
	public ResultSet updatestudent(StudentModel sm);
	public boolean updatestudentdetails(StudentModel sm);
	public boolean deletestudent(StudentModel sm);
	public ArrayList<StudentModel>searchstudentbyID(StudentModel sm);
	public boolean senddueremainder(StudentModel sm);
	public StudentModel viewremainder(String id);
	public boolean accountantlogout(StudentModel sm);
	public boolean studentlogin(StudentModel sm);
	public boolean paystudentfees(StudentModel sm);
	public StudentModel paymentform(String id);
	public boolean forgotstudpwd(StudentModel sm);
	public boolean studentlogout(StudentModel sm);
}
